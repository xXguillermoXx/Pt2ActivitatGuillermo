import java.io.*; 
public class Exercici3GuillermoRuiz {
    public static void main(String[] args) throws IOException {
        int i;
        int y;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Introduce un numero=");
        String numero1 = reader.readLine();
        int numero = Integer.parseInt(numero1);
        if (numero==1){
			System.out.println("+");
		}
		if (numero==2){
			System.out.println("++");
			System.out.println("++");
		}
		if (numero<=3){
			for(i=0;i<numero;i++){
				for(y=0;y<numero;y++){
					System.out.println("+");
				}
			}
		}
    }
}

